(* Paclet Info File *)

(* created 2023.03.08*)

Paclet[
  Name -> "SCWIGE",
  Version -> "0.0.1",
  WolframVersion -> "6+",
  Extensions -> {
    {"Documentation", Language -> "English"}
}]